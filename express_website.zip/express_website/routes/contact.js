var express = require ('express');
var router = express.Router();
var nodemailer = require ('nodemailer');

router.get('/',function(req, res, next){
	res.render('contact', {title:'contact'});
});

router.post('/send',function(req, res, next){
	var transporter = nodemailer.createTransport({
		service: 'Gmail',
		auth: {
			user: 'ganeshmajhi.aak@gmail.com',
			pass: 'something'

		}
	});

	var mailOptions = {
		from:'ganesh <ganeshmajhi@gmail.com>', 
		to : 'ganeshmajhi.aak@gmail.com',
		subject:'website submission',
		text: 'your message is '+req.body.name+'Email'+req.body.email+'Message'+req.body.message,
		html: '<p>your message from</p><ul><li>Name:'+req.body.name+'</li><li>Email:'+req.body.email+'</li><li>Message:'+req.body.message+'</li></ul>'
	};


	transporter.sendMail(mailOptions,function(error,info){
		if(error){
			console.log(error);
			res.redirect('/');
		}else {
			console.log('Message sent :'+ info.response);
			res.redirect('/');
		}
	});
});

module.exports = router;